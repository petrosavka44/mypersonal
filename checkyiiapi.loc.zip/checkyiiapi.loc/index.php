<?php
    
    $cookie     = "cookies.txt";
    
    /******************   AUTHORIZATION BEGIN  *********************/
    $data = array(
        "username" => "admin", 
        "password" => "admin"
    );
    
    $data_string = json_encode($data);                                                                                   
                                                                                                                         
    $url = 'http://testtask/api/v1/authorize';
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_USERAGENT,'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/32.0.1700.107 Chrome/32.0.1700.107 Safari/537.36');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json',
        'Content-Length: '.strlen($data_string))
    );

    curl_setopt($ch, CURLOPT_POST, 1);                                                                     
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
    curl_setopt($ch, CURLOPT_COOKIESESSION, true);
    curl_setopt ($ch, CURLOPT_COOKIEFILE, $cookie); 
    curl_setopt ($ch, CURLOPT_COOKIEJAR,  $cookie);
    
    $result = curl_exec($ch);
    $json_data = json_decode($result);
    
    $token = $json_data->token;
    
    echo '<pre>';
    print_r($token);
    echo '</pre>';
    echo '<br>';
    
    //curl_close ($ch);
    /******************   AUTHORIZATION END  *********************/
    
    /******************   ORDER BEGIN  *********************/
    $data = array(
        "token" => $token,
        "id" => 65
    );
    $data_string = json_encode($data);                                                                                   
                                                                                                                         
    $url = 'http://testtask/api/v1/new_order';
    
    //$ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json',
        'Content-Length: '.strlen($data_string))
    );

    curl_setopt($ch, CURLOPT_POST, 1);                                                                     
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
    
    $result = curl_exec($ch);
    $json_data = json_decode($result);
    
    $status = $json_data->status;
    
    echo '<pre>';
    print_r($status);
    echo '</pre>';
    echo '<br>';
    
    //curl_close ($ch);
    /******************   ORDER END  *********************/
    
    /******************   CARD BEGIN  *********************/
    $data = array(
        "token" => $token,
        "card" => "4587 4521 9853 2547",
        "amount" => 145
    );
    $data_string = json_encode($data);                                                                                   
                                                                                                                         
    $url = 'http://testtask/api/v1/new_transaction';
    
    //$ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json',
        'Content-Length: '.strlen($data_string))
    );

    curl_setopt($ch, CURLOPT_POST, 1);                                                                     
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
    
    $result = curl_exec($ch);
    $json_data = json_decode($result);
    
    $status = $json_data->status;
    
    echo '<pre>';
    print_r($status);
    echo '</pre>';
    echo '<br>';
    
    curl_close ($ch);
    /******************   CARD END  *********************/
    exit;