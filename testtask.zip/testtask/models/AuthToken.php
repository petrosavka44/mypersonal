<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "authToken".
 *
 * @property int $id
 * @property int $userId
 * @property string $token
 * @property string $created
 *
 * @property User $user
 */
class AuthToken extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'authToken';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['id', 'userId', 'token', 'created'], 'required'],
            [['id', 'userId'], 'integer'],
            [['created'], 'safe'],
            [['token'], 'string', 'max' => 255],
            [['token'], 'unique'],
            [['id', 'userId'], 'unique', 'targetAttribute' => ['id', 'userId']],
            [['userId'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['userId' => 'id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'userId' => 'User ID',
            'token' => 'Token',
            'created' => 'Created',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUser()
    {
        return $this->hasOne(User::className(), ['id' => 'userId']);
    }
}
