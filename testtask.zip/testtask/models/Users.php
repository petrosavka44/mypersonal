<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "user".
 *
 * @property int $id
 * @property string $username
 * @property string $password
 * @property string $lastLogin
 * @property string $modified
 * @property string $created
 *
 * @property AuthToken[] $authTokens
 */
class Users extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'user';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['id', 'username', 'password'], 'required'],
            [['id'], 'integer'],
            [['lastLogin', 'modified', 'created'], 'safe'],
            [['username', 'password'], 'string', 'max' => 255],
            [['id'], 'unique'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'username' => 'Username',
            'password' => 'Password',
            'lastLogin' => 'Last Login',
            'modified' => 'Modified',
            'created' => 'Created',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getAuthTokens()
    {
        return $this->hasMany(AuthToken::className(), ['userId' => 'id']);
    }
}
