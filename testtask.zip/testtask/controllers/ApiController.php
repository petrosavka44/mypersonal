<?php

namespace app\controllers;

use Yii;
use yii\filters\VerbFilter;
use yii\web\Request;
use app\models\User;
use yii\filters\auth\HttpBasicAuth;
use app\models\LoginForm;
use yii\web\Response;
use yii\helpers\Json;

class ApiController extends \yii\web\Controller
{
   /**
   * {@inheritdoc}
   */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'index' => ['get'],
                    'authorize' => ['post'],
                    'new_order' => ['post'],
                    'new_transaction' => ['post'],
                ],
            ],
        ];
    }
    
    public function actionIndex()
    {
        return $this->render('index');
    }
    
    public function actionAuthorize()
    {
        $request = Yii::$app->request;
        $session = Yii::$app->session;
        
        if ($request->isPost && $request->post('username') && $request->post('password')) {
            
            $username = $request->post('username');
            $password = $request->post('password');
        
            if (!$session->isActive) {
                $model = new LoginForm();
                
                $model->username = $username;
                $model->password = $password;
                
                if ($model->login()) {                  
                    $session_array = ['token' => Yii::$app->session->getId()];
                
                    return Json::encode($session_array);
                }
            } else {                
                return Json::encode(['token' => Yii::$app->session->getId()]);
            }
            
        }
        
        return Json::encode(['token' => 'Token error']);
    }
    
    public function actionNew_order()
    {
        $request = Yii::$app->request;
        
        if ($request->isPost && $request->post('token') && $request->post('id')) {
            $order_id = (int)$request->post('id');
            
            if (Yii::$app->session->getId() == $request->post('token')) {
            
                $subject = "Yor order number $order_id";
                $text = "Your order number $order_id has been completed";
                $html = "<h1>Your order number $order_id has been completed</h1>";
                
                if ($this->sendMail($subject,$text,$html))
                    return Json::encode(["status" => "Mail with order information was sent (Order#$order_id)"]);
            }
        }
    
        return Json::encode(['status' => 'Request error']);
    }
    
    public function actionNew_transaction()
    {
        $request = Yii::$app->request;
    
        if ($request->isPost && $request->post('token') && $request->post('card') && $request->post('amount')) {
            $card = $request->post('card');
            $amount = (int)$request->post('amount');
        
            if (Yii::$app->session->getId() == $request->post('token')) {
            
                $subject = "Yor card number $card";
                $text = "Your amount $amount";
                $html = "<h1>Your amount $amount</h1>";
                
                if ($this->sendMail($subject,$text,$html))
                    return Json::encode(["status" => "Mail with card number(Card: $card | Amount: $amount) information was sent"]);
            }
        }
    
        return Json::encode(['status' => 'Request error']);
    }
    
    protected function sendMail($subject,$text,$html)
    {
        $result = Yii::$app->mailer->compose()
            ->setFrom('from@domain.com')
            ->setTo('to@domain.com')
            ->setSubject($subject)
            ->setTextBody($text)
            ->setHtmlBody($html)
            ->send();
        
        if ($result)
            return true;
        else
            return false;
    }
    
    public function beforeAction($action) { 
        $this->enableCsrfValidation = false; 
        return parent::beforeAction($action);
    }

}